Writersjumbler Idea, co-pilot helped make.

Required Files - Python 3.12 for windows 10 or 11

open cmd by searching cmd then enter, or right-click in windows 11 goto terminal, from this folder.

py -m pip install -r requirements.txt








USE AT YOUR OWN RISK, IF YOU DO NOT KNOW YOUR WINDOWS PASSWORD ALTHOUGH YOU SHOULD KNOW, YOUR WINDOWS PASSWORD, YOU GET ME.



ONE-CLICK GIF SCREENSAVER

First-time setup:
1. Put screensaver.gif, screensaver_memory_fixed.py, and build_memory_fixed.bat together.
2. Run build_memory_fixed.bat to create GifScreensaver.scr.
3. double-click Run-GifScreensaver.bat in the same folder as GifScreensaver.scr, to start screensaver, takes a little bit, but after moving the mouse or any key, you must put in your password.

