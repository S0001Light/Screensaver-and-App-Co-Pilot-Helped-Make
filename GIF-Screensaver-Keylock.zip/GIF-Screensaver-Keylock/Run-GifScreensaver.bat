@echo off
setlocal
cd /d "%~dp0"

set "SAVER=%~dp0GifScreensaver.scr"

if not exist "%SAVER%" (
    echo GifScreensaver.scr was not found in this folder.
    echo.
    echo Run build_exit_locks.bat first to create it.
    pause
    exit /b 1
)

start "" "%SAVER%" /s
exit /b 0
