import sys, ctypes, ctypes.wintypes, tkinter as tk
from pathlib import Path
from PIL import Image, ImageTk

GIF_NAME='screensaver.gif'
MOUSE_THRESHOLD=8

def asset(name):
    return Path(getattr(sys,'_MEIPASS',Path(__file__).parent))/name

def mode():
    if len(sys.argv)<2: return 'run'
    s=sys.argv[1].lower().replace('-','/').split(':')[0]
    return {'/s':'run','/c':'config','/p':'preview'}.get(s,'run')

def dpi_aware():
    try: ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try: ctypes.windll.user32.SetProcessDPIAware()
        except Exception: pass

def monitor_rects():
    out=[]; RECT=ctypes.wintypes.RECT
    CB=ctypes.WINFUNCTYPE(ctypes.c_int,ctypes.wintypes.HMONITOR,ctypes.wintypes.HDC,ctypes.POINTER(RECT),ctypes.wintypes.LPARAM)
    def cb(_m,_d,p,_x):
        r=p.contents; out.append((r.left,r.top,r.right,r.bottom)); return 1
    cbref=CB(cb); ctypes.windll.user32.EnumDisplayMonitors(None,None,cbref,0)
    return out

class Screen:
    def __init__(self,app,rect,is_root=False):
        l,t,r,b=rect; self.app=app; self.w=r-l; self.h=b-t
        self.win=app.root if is_root else tk.Toplevel(app.root)
        self.win.overrideredirect(True); self.win.attributes('-topmost',True)
        self.win.configure(bg='black',cursor='none')
        xs=f'+{l}' if l>=0 else str(l); ys=f'+{t}' if t>=0 else str(t)
        self.win.geometry(f'{self.w}x{self.h}{xs}{ys}')
        self.canvas=tk.Canvas(self.win,bg='black',bd=0,highlightthickness=0,cursor='none')
        self.canvas.pack(fill='both',expand=True)
        self.item=self.canvas.create_image(0,0,anchor='nw')
        self.tkframe=None
        self.win.bind('<Key>',app.exit_and_lock); self.win.bind('<Button>',app.exit_and_lock)

    def show(self,pil_frame):
        # MEMORY FIX: only one full-screen PhotoImage exists per monitor.
        # The previous build kept every GIF frame at full monitor resolution.
        resized=pil_frame.resize((self.w,self.h),Image.Resampling.BILINEAR)
        self.tkframe=ImageTk.PhotoImage(resized,master=self.win)
        self.canvas.itemconfigure(self.item,image=self.tkframe)

class Saver:
    def __init__(self):
        self.root=tk.Tk(); self.root.withdraw(); self.closing=False; self.start_pointer=None
        self.gif=Image.open(asset(GIF_NAME)); self.frame_count=getattr(self.gif,'n_frames',1); self.frame_index=0
        rects=monitor_rects()
        if not rects: rects=[(0,0,self.root.winfo_screenwidth(),self.root.winfo_screenheight())]
        self.screens=[Screen(self,r,i==0) for i,r in enumerate(rects)]
        self.root.deiconify(); self.next_frame(); self.root.after(2000,self.arm_mouse)

    def next_frame(self):
        if self.closing:return
        try:self.gif.seek(self.frame_index)
        except EOFError:self.frame_index=0; self.gif.seek(0)
        frame=self.gif.convert('RGB')
        delay=max(20,int(self.gif.info.get('duration',100)))
        for screen in self.screens: screen.show(frame)
        self.frame_index=(self.frame_index+1)%self.frame_count
        self.root.after(delay,self.next_frame)

    def arm_mouse(self): self.start_pointer=self.root.winfo_pointerxy(); self.poll_mouse()
    def poll_mouse(self):
        if self.closing:return
        x,y=self.root.winfo_pointerxy(); x0,y0=self.start_pointer
        if abs(x-x0)>=MOUSE_THRESHOLD or abs(y-y0)>=MOUSE_THRESHOLD:self.exit_and_lock();return
        self.root.after(100,self.poll_mouse)

    def exit_and_lock(self,event=None):
        if self.closing:return
        self.closing=True
        try:ctypes.windll.user32.LockWorkStation()
        finally:
            try:self.gif.close();self.root.destroy()
            except Exception:pass
    def run(self):self.root.mainloop()

def main():
    dpi_aware(); m=mode()
    if m=='preview':return
    if m=='config':return
    Saver().run()
if __name__=='__main__':main()
