@echo off
setlocal
cd /d "%~dp0"
py -m pip install Pillow PyInstaller || goto fail
py -m PyInstaller --noconfirm --clean --onefile --windowed --name GifScreensaver --add-data "screensaver.gif;." screensaver_memory_fixed.py || goto fail
copy /y "dist\GifScreensaver.exe" "GifScreensaver.scr" >nul || goto fail
echo Built memory-fixed GifScreensaver.scr
pause
exit /b 0
:fail
echo Build failed.
pause
exit /b 1
