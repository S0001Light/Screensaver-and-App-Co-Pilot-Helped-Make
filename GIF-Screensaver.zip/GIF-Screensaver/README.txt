GIF SCREENSAVER - AUTOMATIC START FIX

1. Replace screensaver.gif with your GIF.
2. Run build_scr.bat on Windows.
3. Right-click GifScreensaver.scr and choose Install.
4. In Screen Saver Settings, select GifScreensaver and click Apply.

This edition fills every connected monitor by stretching the GIF. It avoids Tk mouse-motion events during startup, which could make the saver appear to never turn on when Windows invoked it. Instead, it waits two seconds and polls the physical cursor. A click, key, or real cursor movement closes all windows.

If an older build is selected, reselect the newly built GifScreensaver after installing it.
