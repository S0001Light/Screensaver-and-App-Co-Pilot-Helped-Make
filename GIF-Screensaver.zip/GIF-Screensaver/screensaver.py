import sys, ctypes, ctypes.wintypes, tkinter as tk
from pathlib import Path
from PIL import Image, ImageTk, ImageSequence
GIF_NAME='screensaver.gif'; THRESHOLD=8

def asset(n): return Path(getattr(sys,'_MEIPASS',Path(__file__).parent))/n

def mode():
    if len(sys.argv)<2:return 'run'
    s=sys.argv[1].lower().replace('-','/').split(':')[0]
    return {'/s':'run','/c':'config','/p':'preview'}.get(s,'run')

def dpi():
    try: ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try: ctypes.windll.user32.SetProcessDPIAware()
        except Exception: pass

def monitors():
    found=[]; RECT=ctypes.wintypes.RECT
    CB=ctypes.WINFUNCTYPE(ctypes.c_int,ctypes.wintypes.HMONITOR,ctypes.wintypes.HDC,ctypes.POINTER(RECT),ctypes.wintypes.LPARAM)
    def add(_m,_d,p,_x):
        r=p.contents; found.append((r.left,r.top,r.right,r.bottom)); return 1
    cb=CB(add); ctypes.windll.user32.EnumDisplayMonitors(None,None,cb,0)
    return found

class Screen:
    def __init__(self,app,rect,frames,delays,root=False):
        l,t,r,b=rect; self.w=r-l; self.h=b-t; self.i=0; self.delays=delays
        self.win=app.root if root else tk.Toplevel(app.root)
        self.win.overrideredirect(True); self.win.attributes('-topmost',True); self.win.configure(bg='black')
        xs=f'+{l}' if l>=0 else str(l); ys=f'+{t}' if t>=0 else str(t)
        self.win.geometry(f'{self.w}x{self.h}{xs}{ys}')
        self.canvas=tk.Canvas(self.win,bg='black',bd=0,highlightthickness=0); self.canvas.pack(fill='both',expand=True)
        # Intentionally stretch to fill every monitor.
        self.frames=[ImageTk.PhotoImage(f.resize((self.w,self.h),Image.Resampling.LANCZOS),master=self.win) for f in frames]
        self.item=self.canvas.create_image(0,0,anchor='nw',image=self.frames[0])
        self.win.bind('<Key>',app.close); self.win.bind('<Button>',app.close)
    def animate(self):
        self.canvas.itemconfigure(self.item,image=self.frames[self.i]); d=self.delays[self.i]
        self.i=(self.i+1)%len(self.frames); self.win.after(d,self.animate)

class Saver:
    def __init__(self):
        self.root=tk.Tk(); self.root.withdraw(); self.start=None
        frames=[]; delays=[]
        with Image.open(asset(GIF_NAME)) as im:
            default=int(im.info.get('duration',100))
            for f in ImageSequence.Iterator(im):
                frames.append(f.convert('RGBA').copy()); delays.append(max(20,int(f.info.get('duration',default))))
        self.screens=[Screen(self,r,frames,delays,i==0) for i,r in enumerate(monitors())]
        self.root.deiconify(); [s.animate() for s in self.screens]
        # Critical fix: do not bind <Motion>. Tk can emit startup motion and
        # instantly kill a saver launched automatically by Windows.
        self.root.after(2000,self.arm)
    def arm(self): self.start=self.root.winfo_pointerxy(); self.poll()
    def poll(self):
        x,y=self.root.winfo_pointerxy(); x0,y0=self.start
        if abs(x-x0)>=THRESHOLD or abs(y-y0)>=THRESHOLD: self.close()
        else: self.root.after(100,self.poll)
    def close(self,event=None):
        try:self.root.destroy()
        except tk.TclError:pass
    def run(self):self.root.mainloop()

def main():
    dpi(); m=mode()
    if m=='preview': return
    if m=='config':
        from tkinter import messagebox
        r=tk.Tk();r.withdraw();messagebox.showinfo('GIF Screensaver','Multi-monitor stretched GIF screensaver.');r.destroy();return
    Saver().run()
if __name__=='__main__':main()
