import sys
import ctypes
import ctypes.wintypes
import tkinter as tk
from pathlib import Path
from PIL import Image, ImageTk, ImageSequence

APP_NAME = "Python GIF Screensaver"
GIF_NAME = "screensaver.gif"
BACKGROUND = "black"
MOUSE_EXIT_THRESHOLD = 8


def resource_path(name):
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / name


def parse_mode(argv):
    if len(argv) < 2:
        return "run", None
    raw = argv[1].strip().lower().replace("-", "/")
    if ":" in raw:
        switch, value = raw.split(":", 1)
    else:
        switch = raw
        value = argv[2] if len(argv) > 2 else None
    return {"/s": "run", "/c": "config", "/p": "preview"}.get(switch, "run"), value


def enable_dpi_awareness():
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def get_monitors():
    """Return physical monitor rectangles as (left, top, right, bottom)."""
    if sys.platform != "win32":
        return [(0, 0, 1920, 1080)]
    monitors = []
    RECT = ctypes.wintypes.RECT
    callback_type = ctypes.WINFUNCTYPE(
        ctypes.c_int, ctypes.wintypes.HMONITOR, ctypes.wintypes.HDC,
        ctypes.POINTER(RECT), ctypes.wintypes.LPARAM
    )

    def callback(_monitor, _dc, rect_ptr, _data):
        r = rect_ptr.contents
        monitors.append((r.left, r.top, r.right, r.bottom))
        return 1

    callback_ref = callback_type(callback)
    ctypes.windll.user32.EnumDisplayMonitors(None, None, callback_ref, 0)
    return monitors


class MonitorWindow:
    def __init__(self, app, rect, pil_frames, delays, is_root=False):
        self.app = app
        self.left, self.top, self.right, self.bottom = rect
        self.width = self.right - self.left
        self.height = self.bottom - self.top
        self.window = app.root if is_root else tk.Toplevel(app.root)
        self.window.configure(bg=BACKGROUND)
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        # Negative coordinates are valid for monitors left/above the primary screen.
        x = f"+{self.left}" if self.left >= 0 else str(self.left)
        y = f"+{self.top}" if self.top >= 0 else str(self.top)
        self.window.geometry(f"{self.width}x{self.height}{x}{y}")
        self.canvas = tk.Canvas(self.window, bg=BACKGROUND, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)

        # Stretch every GIF frame to fill this monitor completely.
        # Aspect ratio is intentionally not preserved.
        size = (self.width, self.height)
        self.frames = [ImageTk.PhotoImage(frame.resize(size, Image.Resampling.LANCZOS), master=self.window)
                       for frame in pil_frames]
        self.delays = delays
        self.index = 0
        self.image_id = self.canvas.create_image(self.width // 2, self.height // 2,
                                                 anchor="center", image=self.frames[0])
        for sequence in ("<Key>", "<Button>", "<Motion>"):
            self.window.bind(sequence, app.handle_input)
        self.window.focus_force()

    def animate(self):
        if not self.window.winfo_exists():
            return
        self.canvas.itemconfigure(self.image_id, image=self.frames[self.index])
        delay = self.delays[self.index]
        self.index = (self.index + 1) % len(self.frames)
        self.window.after(delay, self.animate)


class MultiMonitorGifScreenSaver:
    def __init__(self, gif_path):
        self.root = tk.Tk()
        self.root.withdraw()
        self.start_pointer = None
        self.mouse_armed = False
        self.pil_frames, self.delays = self.load_gif(gif_path)
        monitors = get_monitors()
        if not monitors:
            monitors = [(0, 0, self.root.winfo_screenwidth(), self.root.winfo_screenheight())]

        self.windows = []
        for i, rect in enumerate(monitors):
            win = MonitorWindow(self, rect, self.pil_frames, self.delays, is_root=(i == 0))
            self.windows.append(win)
        self.root.deiconify()
        self.root.after(800, self.arm_mouse)
        for win in self.windows:
            win.animate()

    @staticmethod
    def load_gif(path):
        frames, delays = [], []
        with Image.open(path) as image:
            default_delay = int(image.info.get("duration", 100))
            for frame in ImageSequence.Iterator(image):
                frames.append(frame.convert("RGBA").copy())
                delays.append(max(20, int(frame.info.get("duration", default_delay))))
        if not frames:
            raise RuntimeError("The embedded GIF contains no frames.")
        return frames, delays

    def arm_mouse(self):
        self.start_pointer = self.root.winfo_pointerxy()
        self.mouse_armed = True

    def handle_input(self, event):
        if event.type == tk.EventType.Motion:
            if not self.mouse_armed or self.start_pointer is None:
                return
            x0, y0 = self.start_pointer
            if abs(event.x_root - x0) < MOUSE_EXIT_THRESHOLD and abs(event.y_root - y0) < MOUSE_EXIT_THRESHOLD:
                return
        self.close()

    def close(self):
        try:
            self.root.destroy()
        except tk.TclError:
            pass

    def run(self):
        self.root.mainloop()


def show_config_message():
    root = tk.Tk()
    root.withdraw()
    from tkinter import messagebox
    messagebox.showinfo(APP_NAME, "Multi-monitor mode is enabled. The same GIF is shown independently on every connected display.")
    root.destroy()


def main():
    enable_dpi_awareness()
    mode, _parent = parse_mode(sys.argv)
    if mode == "config":
        show_config_message()
        return
    if mode == "preview":
        return
    MultiMonitorGifScreenSaver(resource_path(GIF_NAME)).run()


if __name__ == "__main__":
    main()
