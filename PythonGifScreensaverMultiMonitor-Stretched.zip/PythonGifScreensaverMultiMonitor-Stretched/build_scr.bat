@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher was not found. Install 64-bit Python for Windows first.
  pause
  exit /b 1
)

py -m pip install --upgrade pip
if errorlevel 1 goto :fail
py -m pip install -r requirements.txt
if errorlevel 1 goto :fail

py -m PyInstaller --noconfirm --clean --onefile --windowed --name PythonGifSaver --add-data "screensaver.gif;." screensaver.py
if errorlevel 1 goto :fail

copy /y "dist\PythonGifSaver.exe" "PythonGifSaver.scr" >nul
if errorlevel 1 goto :fail

echo.
echo Built successfully:
echo   %CD%\PythonGifSaver.scr
echo.
echo Right-click PythonGifSaver.scr and select Install.
pause
exit /b 0

:fail
echo.
echo Build failed. Review the messages above.
pause
exit /b 1
