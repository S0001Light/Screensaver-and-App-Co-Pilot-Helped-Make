# Python GIF Multi-Monitor Screensaver

This version creates one borderless window per connected Windows monitor and plays the same embedded GIF on every display. Each copy is stretched to the exact width and height of its monitor, so there are no letterbox bars.

## Build
1. Replace `screensaver.gif` with your GIF, keeping that filename.
2. On Windows, double-click `build_scr.bat`.
3. The finished file is `PythonGifSaver.scr`.
4. Right-click it and choose **Install**.

## Behavior
- `/s`: runs across all detected monitors.
- `/c`: displays an information dialog.
- `/p HWND`: exits cleanly; Control Panel child-window preview is not implemented in this Tkinter template.
- A key press, click, or deliberate mouse movement exits the saver on all monitors.
