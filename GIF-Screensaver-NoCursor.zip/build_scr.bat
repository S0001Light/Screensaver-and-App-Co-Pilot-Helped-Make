@echo off
setlocal
cd /d "%~dp0"
py -m pip install -r requirements.txt || goto fail
py -m PyInstaller --noconfirm --clean --onefile --windowed --name GifScreensaver --add-data "screensaver.gif;." screensaver.py || goto fail
copy /y "dist\GifScreensaver.exe" "GifScreensaver.scr" >nul || goto fail
echo Built: %CD%\GifScreensaver.scr
echo Right-click it, choose Install, reselect it in Screen Saver Settings, and click Apply.
pause
exit /b 0
:fail
echo Build failed.
pause
exit /b 1
